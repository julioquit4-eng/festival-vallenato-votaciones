# Recorta la lámina static/img/stickers-colombia.png en elementos individuales
# con fondo transparente (static/img/stickers/*.png). Uso:
#   powershell -ExecutionPolicy Bypass -File tools\crop-stickers.ps1
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
$src  = Join-Path $root 'static\img\stickers-colombia.png'
$out  = Join-Path $root 'static\img\stickers'
New-Item -ItemType Directory -Force -Path $out | Out-Null

# nombre = x, y, ancho, alto (coordenadas sobre la lámina de 576x1024)
$regions = [ordered]@{
  'carrito'    = @(8, 38, 226, 282)
  'baile'      = @(240, 45, 223, 368)
  'loro'       = @(452, 16, 94, 174)
  'bunuelos'   = @(458, 238, 96, 118)
  'chocoramo'  = @(0, 338, 166, 98)
  'domino'     = @(242, 464, 92, 92)
  'trinitaria' = @(362, 414, 214, 266)
  'platano'    = @(0, 452, 302, 570)
  'sancocho'   = @(413, 720, 112, 108)
  'sillas'     = @(250, 826, 204, 196)
}

$sheet = New-Object System.Drawing.Bitmap $src

foreach ($name in $regions.Keys) {
  $r = $regions[$name]
  $rect = New-Object System.Drawing.Rectangle $r[0], $r[1], $r[2], $r[3]
  $bmp = $sheet.Clone($rect, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)

  $data = $bmp.LockBits((New-Object System.Drawing.Rectangle 0, 0, $bmp.Width, $bmp.Height),
    [System.Drawing.Imaging.ImageLockMode]::ReadWrite,
    [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $len = [Math]::Abs($data.Stride) * $bmp.Height
  $bytes = New-Object byte[] $len
  [System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $bytes, 0, $len)

  for ($i = 0; $i -lt $len; $i += 4) {
    # BGRA: el blanco del fondo se vuelve transparente (con borde suavizado)
    $min = [Math]::Min([Math]::Min($bytes[$i], $bytes[$i + 1]), $bytes[$i + 2])
    if ($min -ge 238) { $bytes[$i + 3] = 0 }
    elseif ($min -ge 215) { $bytes[$i + 3] = [byte](255 * (238 - $min) / 23) }
  }

  [System.Runtime.InteropServices.Marshal]::Copy($bytes, 0, $data.Scan0, $len)
  $bmp.UnlockBits($data)
  $bmp.Save((Join-Path $out "$name.png"), [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Host "OK $name.png"
}
$sheet.Dispose()
