<#
.SYNOPSIS
  Genera la vista previa estática (carpeta /preview) a partir de las plantillas Django de /templates.

.DESCRIPTION
  Las plantillas de /templates son la FUENTE ÚNICA de la interfaz y están escritas con sintaxis de
  Django Templates. Como el prototipo debe poder revisarse sin Python, este script implementa un
  subconjunto mínimo del motor de plantillas y produce archivos HTML planos en /preview.

  Etiquetas soportadas:
    {% extends "x" %}  {% block n %}...{% endblock %}  {% include "x" %}  {% load ... %}
    {% static 'ruta' %}  {% url 'nombre' ... %}  {% csrf_token %}
    {% comment %}...{% endcomment %}  {# ... #}  {{ variable|default:"texto" }}

  Cualquier otra etiqueta se elimina y se informa como advertencia.
  NO sustituye a Django: en la integración real las plantillas las renderiza Django.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File tools\build-preview.ps1
#>
$ErrorActionPreference = 'Stop'

$Root         = Split-Path -Parent $PSScriptRoot
$TemplatesDir = Join-Path $Root 'templates'
$OutDir       = Join-Path $Root 'preview'
$StaticPrefix = '../static/'
$Utf8NoBom    = New-Object System.Text.UTF8Encoding($false)

# Nombre de URL Django  ->  plantilla de origen  ->  archivo de salida
# Mantener sincronizado con docs/INTEGRACION_DJANGO.md (tabla de rutas sugeridas).
$Routes = [ordered]@{
  'public:inicio'            = @('public/inicio.html',            'inicio.html')
  'public:votaciones'        = @('public/votaciones.html',        'votaciones.html')
  'public:detalle_votacion'  = @('public/detalle_votacion.html',  'detalle-votacion.html')
  'public:acceso_votante'    = @('public/acceso_votante.html',    'acceso-votante.html')
  'public:confirmar_voto'    = @('public/confirmar_voto.html',    'confirmar-voto.html')
  'public:comprobante'       = @('public/comprobante.html',       'comprobante.html')
  'public:resultados'        = @('public/resultados.html',        'resultados.html')
  'public:guia'              = @('public/guia.html',              'guia.html')
  'public:privacidad'        = @('public/privacidad.html',        'privacidad.html')
  'public:login'             = @('public/login.html',             'login.html')
  'panel:dashboard'          = @('panel/dashboard.html',          'panel-dashboard.html')
  'panel:ediciones'          = @('panel/ediciones.html',          'panel-ediciones.html')
  'panel:categorias'         = @('panel/categorias.html',         'panel-categorias.html')
  'panel:opciones'           = @('panel/opciones.html',           'panel-opciones.html')
  'panel:votaciones'         = @('panel/votaciones.html',         'panel-votaciones.html')
  'panel:votantes'           = @('panel/votantes.html',           'panel-votantes.html')
  'panel:reportes'           = @('panel/reportes.html',           'panel-reportes.html')
}

$script:Warnings = New-Object System.Collections.Generic.List[string]

function Read-Template([string]$name) {
  $path = Join-Path $TemplatesDir ($name -replace '/', '\')
  if (-not (Test-Path $path)) { throw "Plantilla no encontrada: $name" }
  $text = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
  # Comentarios de Django
  $text = [regex]::Replace($text, '(?s)\{%\s*comment\s*%\}.*?\{%\s*endcomment\s*%\}', '')
  $text = [regex]::Replace($text, '(?s)\{#.*?#\}', '')
  # Includes (recursivos)
  $text = [regex]::Replace($text, '\{%\s*include\s+["'']([^"'']+)["'']\s*%\}', {
    param($m) Read-Template $m.Groups[1].Value
  })
  return $text
}

$BlockTokenPattern = '\{%\s*block\s+(\w+)\s*%\}|\{%\s*endblock(?:\s+\w+)?\s*%\}'

# Devuelve un diccionario nombre -> contenido interno para todos los bloques (cualquier profundidad).
function Get-Blocks([string]$text) {
  $blocks = @{}
  $stack  = New-Object System.Collections.Stack
  foreach ($m in [regex]::Matches($text, $BlockTokenPattern)) {
    if ($m.Groups[1].Success) {
      $stack.Push(@($m.Groups[1].Value, ($m.Index + $m.Length)))
    } else {
      if ($stack.Count -eq 0) { throw 'endblock sin block de apertura' }
      $open = $stack.Pop()
      $blocks[$open[0]] = $text.Substring($open[1], $m.Index - $open[1])
    }
  }
  if ($stack.Count -ne 0) { throw 'block sin endblock' }
  return $blocks
}

# Sustituye los bloques de primer nivel por su versión sobrescrita (o la propia) de forma recursiva.
function Resolve-Blocks([string]$text, [hashtable]$overrides) {
  $sb = New-Object System.Text.StringBuilder
  $depth = 0; $cursor = 0; $name = $null; $innerStart = 0
  foreach ($m in [regex]::Matches($text, $BlockTokenPattern)) {
    if ($m.Groups[1].Success) {
      if ($depth -eq 0) {
        [void]$sb.Append($text.Substring($cursor, $m.Index - $cursor))
        $name = $m.Groups[1].Value
        $innerStart = $m.Index + $m.Length
      }
      $depth++
    } else {
      $depth--
      if ($depth -eq 0) {
        $inner = $text.Substring($innerStart, $m.Index - $innerStart)
        if ($overrides.ContainsKey($name)) { $inner = $overrides[$name] }
        [void]$sb.Append((Resolve-Blocks $inner $overrides))
        $cursor = $m.Index + $m.Length
      }
    }
  }
  [void]$sb.Append($text.Substring($cursor))
  return $sb.ToString()
}

function Render-Page([string]$name) {
  $text = Read-Template $name
  $overrides = @{}
  $guard = 0
  while ($text -match '\{%\s*extends\s+["'']([^"'']+)["'']\s*%\}') {
    $parent = $Matches[1]
    $blocks = Get-Blocks $text
    foreach ($k in $blocks.Keys) { if (-not $overrides.ContainsKey($k)) { $overrides[$k] = $blocks[$k] } }
    $text = Read-Template $parent
    if (++$guard -gt 10) { throw "Herencia demasiado profunda en $name" }
  }
  $html = Resolve-Blocks $text $overrides

  $html = [regex]::Replace($html, '\{%\s*load\s+[^%]*%\}', '')
  $html = [regex]::Replace($html, '\{%\s*csrf_token\s*%\}', '')
  $html = [regex]::Replace($html, '\{%\s*static\s+["'']([^"'']*)["'']\s*%\}', { param($m) $StaticPrefix + $m.Groups[1].Value })
  $html = [regex]::Replace($html, '\{%\s*url\s+["'']([^"'']+)["''][^%]*%\}', {
    param($m)
    $key = $m.Groups[1].Value
    if ($Routes.Contains($key)) { return $Routes[$key][1] }
    $script:Warnings.Add("URL sin mapear '$key' en $name"); return '#'
  })
  $html = [regex]::Replace($html, '\{\{\s*[\w\.]+\s*\|\s*default:\s*"([^"]*)"\s*\}\}', '$1')
  foreach ($m in [regex]::Matches($html, '\{\{.*?\}\}|\{%.*?%\}')) { $script:Warnings.Add("Etiqueta no soportada '$($m.Value)' en $name") }
  $html = [regex]::Replace($html, '\{\{.*?\}\}|\{%.*?%\}', '')

  # Limpieza de líneas vacías consecutivas generadas por las etiquetas eliminadas
  $html = [regex]::Replace($html, '(\r?\n[ \t]*){3,}', "`r`n`r`n")
  $banner = "<!-- ARCHIVO GENERADO desde templates/$name por tools/build-preview.ps1. No editar: modifica la plantilla Django. -->"
  $html = [regex]::Replace($html.TrimStart(), '^(<!DOCTYPE html>)', "`$1`r`n$banner", 'IgnoreCase')
  return $html
}

if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
foreach ($key in $Routes.Keys) {
  $src = $Routes[$key][0]; $out = $Routes[$key][1]
  $html = Render-Page $src
  [System.IO.File]::WriteAllText((Join-Path $OutDir $out), $html, $Utf8NoBom)
  Write-Host ("  OK  {0,-34} -> preview/{1}" -f $src, $out)
}
if ($script:Warnings.Count) {
  Write-Host "`nAdvertencias:" -ForegroundColor Yellow
  $script:Warnings | Select-Object -Unique | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
} else {
  Write-Host "`nVista previa generada sin advertencias en: $OutDir" -ForegroundColor Green
}
