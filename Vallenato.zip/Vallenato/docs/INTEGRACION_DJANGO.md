# Guía de Integración Backend (Django + MySQL)
## Sistema Web de Votaciones — Festival de la Leyenda Vallenata 2027

Este documento resume la arquitectura de la capa de presentación desarrollada y detalla las pautas para que el desarrollador backend conecte las vistas, modelos y base de datos sin alterar la estructura visual ni el diseño.

---

### 1. Estructura del Proyecto

```text
Vallenato/
├── preview/                     # Vistas HTML planas para previsualización inmediata en navegador
├── static/
│   ├── css/
│   │   ├── styles.css           # Tokens de diseño (paleta Verde Bosque/Esmeralda, tipografía, variables)
│   │   ├── public.css           # Estilos del portal ciudadano
│   │   └── admin.css            # Estilos del panel de control electoral
│   ├── js/
│   │   ├── demo-data.js         # Datos ficticios centralizados (ELIMINAR AL INTEGRAR CON DJANGO)
│   │   ├── main.js              # Núcleo JS, toasts, validaciones y mapeo de URLs
│   │   ├── voting.js            # Lógica interactiva del portal público (P1 a P8)
│   │   └── admin.js             # Lógica interactiva del panel de gestión (P9 a P14)
│   └── img/                     # Recursos visuales culturales (acordeón, paisajes, instrumentos)
├── templates/                   # Fuentes de plantillas compatibles con Django Template Engine
│   ├── base.html                # Plantilla raíz
│   ├── partials/                # Componentes reutilizables (header, footer, modales, toasts)
│   ├── public/                  # Pantallas del portal público (inicio, votaciones, detalle, etc.)
│   └── panel/                   # Pantallas del panel administrativo (dashboard, censo, reportes, etc.)
└── tools/
    └── build-preview.ps1        # Script para compilar las plantillas Django a la carpeta /preview
```

---

### 2. Mapeo de Rutas y Vistas Sugeridas (Django `urls.py`)

Configura tus aplicaciones en Django respetando los siguientes `names`:

#### Portal Público (`namespace='public'`)
| Nombre de Ruta Django | Vista / Propósito | Plantilla Asociada |
| :--- | :--- | :--- |
| `public:inicio` | Home / Hero y destacadas | `templates/public/inicio.html` |
| `public:votaciones` | Listado general y filtros | `templates/public/votaciones.html` |
| `public:detalle_votacion` | Ficha y selección uninominal | `templates/public/detalle_votacion.html` |
| `public:acceso_votante` | Verificación en padrón | `templates/public/acceso_votante.html` |
| `public:confirmar_voto` | Resumen previo y modal | `templates/public/confirmar_voto.html` |
| `public:comprobante` | Recibo de confirmación | `templates/public/comprobante.html` |
| `public:resultados` | Escrutinio público auditado | `templates/public/resultados.html` |
| `public:guia` | Cronograma y FAQ | `templates/public/guia.html` |
| `public:privacidad` | Marco de Habeas Data | `templates/public/privacidad.html` |

#### Panel Administrativo (`namespace='panel'`)
| Nombre de Ruta Django | Vista / Propósito | Plantilla Asociada |
| :--- | :--- | :--- |
| `panel:dashboard` | KPIs y actividad reciente | `templates/panel/dashboard.html` |
| `panel:ediciones` | Gestión de certámenes | `templates/panel/ediciones.html` |
| `panel:categorias` | Categorías de competencia | `templates/panel/categorias.html` |
| `panel:votaciones` | Configuración de procesos | `templates/panel/votaciones.html` |
| `panel:opciones` | Registro de candidatos | `templates/panel/opciones.html` |
| `panel:votantes` | Censo y carga de CSV | `templates/panel/votantes.html` |
| `panel:reportes` | Descarga de escrutinios | `templates/panel/reportes.html` |

---

### 3. Puntos Clave de Integración

1. **Tokens CSRF:**  
   Todos los formularios `<form>` en `templates/` cuentan con la etiqueta `{% csrf_token %}` para proteger contra solicitudes cruzadas no autorizadas.
2. **Reemplazo de Datos Mock:**  
   En las plantillas se encuentran bloques comentados `{% comment %} PUNTO DE INTEGRACIÓN {% endcomment %}` donde se puede reemplazar la inyección JavaScript por bucles nativos de Django (ej. `{% for v in votaciones %} ... {% endfor %}`).
3. **Desacoplamiento de `demo-data.js`:**  
   Una vez que las vistas de Django entreguen el contexto con los modelos reales de MySQL, basta con retirar la etiqueta `<script src="{% static 'js/demo-data.js' %}"></script>` en `templates/base.html` y `templates/panel/base_panel.html`.
